﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace практическая_4
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }

    

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            try
            {
                int proizvod;
                int s = 0;
                int b = Convert.ToInt32(text1.Text);
                int[] mas = new int[b];
                for (int i = 0; i < b; i++)
                {
                    mas[i] = s + 1;
                    s = mas[i];
                    list1.Items.Add(Convert.ToString(mas[i]));
                }
                for (int i = 0; i < b; i++)
                {
                    if (mas[i] % 2 == 1)
                    {
                        proizvod = mas[i];
                        proizvod *= 2;
                        list2.Items.Add(Convert.ToString(proizvod));
                    }
                    else
                    if (mas[i] % 2 == 0)
                    {
                        proizvod = mas[i];
                        proizvod += proizvod + proizvod + 1;
                        list2.Items.Add(Convert.ToString(proizvod));
                    }
                }

            }
            catch 
            {
                MessageBox.Show("Проверьте введённые данные!", "Ошибка!");
            }
        }

        private void Button_Click_3(object sender, RoutedEventArgs e)
        {
            text1.Clear();
            list1.Items.Clear();
            list2.Items.Clear();
        }
    }
}
